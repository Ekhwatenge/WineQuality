```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the datasets
#red_wine = pd.read_names('Documents/Documents/MLProject/WineQuality/wine+quality/winequality.names', delimiter=';')
#red_wine =pd.read_csv('Documents/Documents/MLProject/WineQuality/wine+quality/winequality-red.csv', delimeter=';')
#white_wine = pd.read_csv('Documents/Documents/MLProject/WineQuality/wine+quality/winequality-white.csv', delimiter=';')

# Load the datasets
# the .names file contains metadata or descriptions and not data to be loaded as a DataFrame
with open('Documents/Documents/MLProject/WineQuality/wine+quality/winequality.names', 'r') as file:
    wine_names_info = file.readlines()
    print("Contents of winequality.names file:")
    print("".join(wine_names_info))

# Load the red and white wine datasets
red_wine = pd.read_csv('Documents/Documents/MLProject/WineQuality/wine+quality/winequality-red.csv', delimiter=';')
white_wine = pd.read_csv('Documents/Documents/MLProject/WineQuality/wine+quality/winequality-white.csv', delimiter=';')
# Basic statistics
red_stats = red_wine.describe()
white_stats = white_wine.describe()

# Calculate correlation matrices
red_corr = red_wine.corr()
white_corr = white_wine.corr()
```

    Contents of winequality.names file:
    Citation Request:
      This dataset is public available for research. The details are described in [Cortez et al., 2009]. 
      Please include this citation if you plan to use this database:
    
      P. Cortez, A. Cerdeira, F. Almeida, T. Matos and J. Reis. 
      Modeling wine preferences by data mining from physicochemical properties.
      In Decision Support Systems, Elsevier, 47(4):547-553. ISSN: 0167-9236.
    
      Available at: [@Elsevier] http://dx.doi.org/10.1016/j.dss.2009.05.016
                    [Pre-press (pdf)] http://www3.dsi.uminho.pt/pcortez/winequality09.pdf
                    [bib] http://www3.dsi.uminho.pt/pcortez/dss09.bib
    
    1. Title: Wine Quality 
    
    2. Sources
       Created by: Paulo Cortez (Univ. Minho), Antonio Cerdeira, Fernando Almeida, Telmo Matos and Jose Reis (CVRVV) @ 2009
       
    3. Past Usage:
    
      P. Cortez, A. Cerdeira, F. Almeida, T. Matos and J. Reis. 
      Modeling wine preferences by data mining from physicochemical properties.
      In Decision Support Systems, Elsevier, 47(4):547-553. ISSN: 0167-9236.
    
      In the above reference, two datasets were created, using red and white wine samples.
      The inputs include objective tests (e.g. PH values) and the output is based on sensory data
      (median of at least 3 evaluations made by wine experts). Each expert graded the wine quality 
      between 0 (very bad) and 10 (very excellent). Several data mining methods were applied to model
      these datasets under a regression approach. The support vector machine model achieved the
      best results. Several metrics were computed: MAD, confusion matrix for a fixed error tolerance (T),
      etc. Also, we plot the relative importances of the input variables (as measured by a sensitivity
      analysis procedure).
     
    4. Relevant Information:
    
       The two datasets are related to red and white variants of the Portuguese "Vinho Verde" wine.
       For more details, consult: http://www.vinhoverde.pt/en/ or the reference [Cortez et al., 2009].
       Due to privacy and logistic issues, only physicochemical (inputs) and sensory (the output) variables 
       are available (e.g. there is no data about grape types, wine brand, wine selling price, etc.).
    
       These datasets can be viewed as classification or regression tasks.
       The classes are ordered and not balanced (e.g. there are munch more normal wines than
       excellent or poor ones). Outlier detection algorithms could be used to detect the few excellent
       or poor wines. Also, we are not sure if all input variables are relevant. So
       it could be interesting to test feature selection methods. 
    
    5. Number of Instances: red wine - 1599; white wine - 4898. 
    
    6. Number of Attributes: 11 + output attribute
      
       Note: several of the attributes may be correlated, thus it makes sense to apply some sort of
       feature selection.
    
    7. Attribute information:
    
       For more information, read [Cortez et al., 2009].
    
       Input variables (based on physicochemical tests):
       1 - fixed acidity
       2 - volatile acidity
       3 - citric acid
       4 - residual sugar
       5 - chlorides
       6 - free sulfur dioxide
       7 - total sulfur dioxide
       8 - density
       9 - pH
       10 - sulphates
       11 - alcohol
       Output variable (based on sensory data): 
       12 - quality (score between 0 and 10)
    
    8. Missing Attribute Values: None
    
    


```python
# Display first few rows of each dataset
print("Red Wine Data:")
print(red_wine.head())
print("\nWhite Wine Data:")
print(white_wine.head())

# Check for missing values and data types
print("\nRed Wine Info:")
print(red_wine.info())
print("\nWhite Wine Info:")
print(white_wine.info())

# Display column names available in `winequality.names`, match them here
print("\nColumn Names:")
print(red_wine.columns)
```

    Red Wine Data:
       fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  \
    0            7.4              0.70         0.00             1.9      0.076   
    1            7.8              0.88         0.00             2.6      0.098   
    2            7.8              0.76         0.04             2.3      0.092   
    3           11.2              0.28         0.56             1.9      0.075   
    4            7.4              0.70         0.00             1.9      0.076   
    
       free sulfur dioxide  total sulfur dioxide  density    pH  sulphates  \
    0                 11.0                  34.0   0.9978  3.51       0.56   
    1                 25.0                  67.0   0.9968  3.20       0.68   
    2                 15.0                  54.0   0.9970  3.26       0.65   
    3                 17.0                  60.0   0.9980  3.16       0.58   
    4                 11.0                  34.0   0.9978  3.51       0.56   
    
       alcohol  quality  
    0      9.4        5  
    1      9.8        5  
    2      9.8        5  
    3      9.8        6  
    4      9.4        5  
    
    White Wine Data:
       fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  \
    0            7.0              0.27         0.36            20.7      0.045   
    1            6.3              0.30         0.34             1.6      0.049   
    2            8.1              0.28         0.40             6.9      0.050   
    3            7.2              0.23         0.32             8.5      0.058   
    4            7.2              0.23         0.32             8.5      0.058   
    
       free sulfur dioxide  total sulfur dioxide  density    pH  sulphates  \
    0                 45.0                 170.0   1.0010  3.00       0.45   
    1                 14.0                 132.0   0.9940  3.30       0.49   
    2                 30.0                  97.0   0.9951  3.26       0.44   
    3                 47.0                 186.0   0.9956  3.19       0.40   
    4                 47.0                 186.0   0.9956  3.19       0.40   
    
       alcohol  quality  
    0      8.8        6  
    1      9.5        6  
    2     10.1        6  
    3      9.9        6  
    4      9.9        6  
    
    Red Wine Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1599 entries, 0 to 1598
    Data columns (total 12 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   fixed acidity         1599 non-null   float64
     1   volatile acidity      1599 non-null   float64
     2   citric acid           1599 non-null   float64
     3   residual sugar        1599 non-null   float64
     4   chlorides             1599 non-null   float64
     5   free sulfur dioxide   1599 non-null   float64
     6   total sulfur dioxide  1599 non-null   float64
     7   density               1599 non-null   float64
     8   pH                    1599 non-null   float64
     9   sulphates             1599 non-null   float64
     10  alcohol               1599 non-null   float64
     11  quality               1599 non-null   int64  
    dtypes: float64(11), int64(1)
    memory usage: 150.0 KB
    None
    
    White Wine Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4898 entries, 0 to 4897
    Data columns (total 12 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   fixed acidity         4898 non-null   float64
     1   volatile acidity      4898 non-null   float64
     2   citric acid           4898 non-null   float64
     3   residual sugar        4898 non-null   float64
     4   chlorides             4898 non-null   float64
     5   free sulfur dioxide   4898 non-null   float64
     6   total sulfur dioxide  4898 non-null   float64
     7   density               4898 non-null   float64
     8   pH                    4898 non-null   float64
     9   sulphates             4898 non-null   float64
     10  alcohol               4898 non-null   float64
     11  quality               4898 non-null   int64  
    dtypes: float64(11), int64(1)
    memory usage: 459.3 KB
    None
    
    Column Names:
    Index(['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
           'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density',
           'pH', 'sulphates', 'alcohol', 'quality'],
          dtype='object')
    


```python
# Display the first few rows of both datasets
print("Red Wine Dataset Overview:")
print(red_wine.head())

print("\nWhite Wine Dataset Overview:")
print(white_wine.head())

# Display basic statistics
print("\nRed Wine Dataset Statistics Summary:")
print(red_stats)

print("\nWhite Wine Dataset Statistics Summary:")
print(white_stats)

# Recalculate correlation matrices
red_corr = red_wine.corr()
white_corr = white_wine.corr()

# Display correlation matrices
print("\nRed Wine Correlation Matrix:")
print(red_corr)

print("\nWhite Wine Correlation Matrix:")
print(white_corr)
# Display missing values and duplicate rows
print("\nRed Wine Missing Values:")
print(red_missing)

print("\nWhite Wine Missing Values:")
print(white_missing)

print("\nRed Wine Duplicate Rows Count:")
print(red_duplicates)

print("\nWhite Wine Duplicate Rows Count:")
print(white_duplicates)
```

    Red Wine Dataset Overview:
       fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  \
    0            7.4              0.70         0.00             1.9      0.076   
    1            7.8              0.88         0.00             2.6      0.098   
    2            7.8              0.76         0.04             2.3      0.092   
    3           11.2              0.28         0.56             1.9      0.075   
    4            7.4              0.70         0.00             1.9      0.076   
    
       free sulfur dioxide  total sulfur dioxide  density    pH  sulphates  \
    0                 11.0                  34.0   0.9978  3.51       0.56   
    1                 25.0                  67.0   0.9968  3.20       0.68   
    2                 15.0                  54.0   0.9970  3.26       0.65   
    3                 17.0                  60.0   0.9980  3.16       0.58   
    4                 11.0                  34.0   0.9978  3.51       0.56   
    
       alcohol  quality  
    0      9.4        5  
    1      9.8        5  
    2      9.8        5  
    3      9.8        6  
    4      9.4        5  
    
    White Wine Dataset Overview:
       fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  \
    0            7.0              0.27         0.36            20.7      0.045   
    1            6.3              0.30         0.34             1.6      0.049   
    2            8.1              0.28         0.40             6.9      0.050   
    3            7.2              0.23         0.32             8.5      0.058   
    4            7.2              0.23         0.32             8.5      0.058   
    
       free sulfur dioxide  total sulfur dioxide  density    pH  sulphates  \
    0                 45.0                 170.0   1.0010  3.00       0.45   
    1                 14.0                 132.0   0.9940  3.30       0.49   
    2                 30.0                  97.0   0.9951  3.26       0.44   
    3                 47.0                 186.0   0.9956  3.19       0.40   
    4                 47.0                 186.0   0.9956  3.19       0.40   
    
       alcohol  quality  
    0      8.8        6  
    1      9.5        6  
    2     10.1        6  
    3      9.9        6  
    4      9.9        6  
    
    Red Wine Dataset Statistics Summary:
           fixed acidity  volatile acidity  citric acid  residual sugar  \
    count    1599.000000       1599.000000  1599.000000     1599.000000   
    mean        8.319637          0.527821     0.270976        2.538806   
    std         1.741096          0.179060     0.194801        1.409928   
    min         4.600000          0.120000     0.000000        0.900000   
    25%         7.100000          0.390000     0.090000        1.900000   
    50%         7.900000          0.520000     0.260000        2.200000   
    75%         9.200000          0.640000     0.420000        2.600000   
    max        15.900000          1.580000     1.000000       15.500000   
    
             chlorides  free sulfur dioxide  total sulfur dioxide      density  \
    count  1599.000000          1599.000000           1599.000000  1599.000000   
    mean      0.087467            15.874922             46.467792     0.996747   
    std       0.047065            10.460157             32.895324     0.001887   
    min       0.012000             1.000000              6.000000     0.990070   
    25%       0.070000             7.000000             22.000000     0.995600   
    50%       0.079000            14.000000             38.000000     0.996750   
    75%       0.090000            21.000000             62.000000     0.997835   
    max       0.611000            72.000000            289.000000     1.003690   
    
                    pH    sulphates      alcohol      quality  
    count  1599.000000  1599.000000  1599.000000  1599.000000  
    mean      3.311113     0.658149    10.422983     5.636023  
    std       0.154386     0.169507     1.065668     0.807569  
    min       2.740000     0.330000     8.400000     3.000000  
    25%       3.210000     0.550000     9.500000     5.000000  
    50%       3.310000     0.620000    10.200000     6.000000  
    75%       3.400000     0.730000    11.100000     6.000000  
    max       4.010000     2.000000    14.900000     8.000000  
    
    White Wine Dataset Statistics Summary:
           fixed acidity  volatile acidity  citric acid  residual sugar  \
    count    4898.000000       4898.000000  4898.000000     4898.000000   
    mean        6.854788          0.278241     0.334192        6.391415   
    std         0.843868          0.100795     0.121020        5.072058   
    min         3.800000          0.080000     0.000000        0.600000   
    25%         6.300000          0.210000     0.270000        1.700000   
    50%         6.800000          0.260000     0.320000        5.200000   
    75%         7.300000          0.320000     0.390000        9.900000   
    max        14.200000          1.100000     1.660000       65.800000   
    
             chlorides  free sulfur dioxide  total sulfur dioxide      density  \
    count  4898.000000          4898.000000           4898.000000  4898.000000   
    mean      0.045772            35.308085            138.360657     0.994027   
    std       0.021848            17.007137             42.498065     0.002991   
    min       0.009000             2.000000              9.000000     0.987110   
    25%       0.036000            23.000000            108.000000     0.991723   
    50%       0.043000            34.000000            134.000000     0.993740   
    75%       0.050000            46.000000            167.000000     0.996100   
    max       0.346000           289.000000            440.000000     1.038980   
    
                    pH    sulphates      alcohol      quality  
    count  4898.000000  4898.000000  4898.000000  4898.000000  
    mean      3.188267     0.489847    10.514267     5.877909  
    std       0.151001     0.114126     1.230621     0.885639  
    min       2.720000     0.220000     8.000000     3.000000  
    25%       3.090000     0.410000     9.500000     5.000000  
    50%       3.180000     0.470000    10.400000     6.000000  
    75%       3.280000     0.550000    11.400000     6.000000  
    max       3.820000     1.080000    14.200000     9.000000  
    
    Red Wine Correlation Matrix:
                          fixed acidity  volatile acidity  citric acid  \
    fixed acidity              1.000000         -0.256131     0.671703   
    volatile acidity          -0.256131          1.000000    -0.552496   
    citric acid                0.671703         -0.552496     1.000000   
    residual sugar             0.114777          0.001918     0.143577   
    chlorides                  0.093705          0.061298     0.203823   
    free sulfur dioxide       -0.153794         -0.010504    -0.060978   
    total sulfur dioxide      -0.113181          0.076470     0.035533   
    density                    0.668047          0.022026     0.364947   
    pH                        -0.682978          0.234937    -0.541904   
    sulphates                  0.183006         -0.260987     0.312770   
    alcohol                   -0.061668         -0.202288     0.109903   
    quality                    0.124052         -0.390558     0.226373   
    
                          residual sugar  chlorides  free sulfur dioxide  \
    fixed acidity               0.114777   0.093705            -0.153794   
    volatile acidity            0.001918   0.061298            -0.010504   
    citric acid                 0.143577   0.203823            -0.060978   
    residual sugar              1.000000   0.055610             0.187049   
    chlorides                   0.055610   1.000000             0.005562   
    free sulfur dioxide         0.187049   0.005562             1.000000   
    total sulfur dioxide        0.203028   0.047400             0.667666   
    density                     0.355283   0.200632            -0.021946   
    pH                         -0.085652  -0.265026             0.070377   
    sulphates                   0.005527   0.371260             0.051658   
    alcohol                     0.042075  -0.221141            -0.069408   
    quality                     0.013732  -0.128907            -0.050656   
    
                          total sulfur dioxide   density        pH  sulphates  \
    fixed acidity                    -0.113181  0.668047 -0.682978   0.183006   
    volatile acidity                  0.076470  0.022026  0.234937  -0.260987   
    citric acid                       0.035533  0.364947 -0.541904   0.312770   
    residual sugar                    0.203028  0.355283 -0.085652   0.005527   
    chlorides                         0.047400  0.200632 -0.265026   0.371260   
    free sulfur dioxide               0.667666 -0.021946  0.070377   0.051658   
    total sulfur dioxide              1.000000  0.071269 -0.066495   0.042947   
    density                           0.071269  1.000000 -0.341699   0.148506   
    pH                               -0.066495 -0.341699  1.000000  -0.196648   
    sulphates                         0.042947  0.148506 -0.196648   1.000000   
    alcohol                          -0.205654 -0.496180  0.205633   0.093595   
    quality                          -0.185100 -0.174919 -0.057731   0.251397   
    
                           alcohol   quality  
    fixed acidity        -0.061668  0.124052  
    volatile acidity     -0.202288 -0.390558  
    citric acid           0.109903  0.226373  
    residual sugar        0.042075  0.013732  
    chlorides            -0.221141 -0.128907  
    free sulfur dioxide  -0.069408 -0.050656  
    total sulfur dioxide -0.205654 -0.185100  
    density              -0.496180 -0.174919  
    pH                    0.205633 -0.057731  
    sulphates             0.093595  0.251397  
    alcohol               1.000000  0.476166  
    quality               0.476166  1.000000  
    
    White Wine Correlation Matrix:
                          fixed acidity  volatile acidity  citric acid  \
    fixed acidity              1.000000         -0.022697     0.289181   
    volatile acidity          -0.022697          1.000000    -0.149472   
    citric acid                0.289181         -0.149472     1.000000   
    residual sugar             0.089021          0.064286     0.094212   
    chlorides                  0.023086          0.070512     0.114364   
    free sulfur dioxide       -0.049396         -0.097012     0.094077   
    total sulfur dioxide       0.091070          0.089261     0.121131   
    density                    0.265331          0.027114     0.149503   
    pH                        -0.425858         -0.031915    -0.163748   
    sulphates                 -0.017143         -0.035728     0.062331   
    alcohol                   -0.120881          0.067718    -0.075729   
    quality                   -0.113663         -0.194723    -0.009209   
    
                          residual sugar  chlorides  free sulfur dioxide  \
    fixed acidity               0.089021   0.023086            -0.049396   
    volatile acidity            0.064286   0.070512            -0.097012   
    citric acid                 0.094212   0.114364             0.094077   
    residual sugar              1.000000   0.088685             0.299098   
    chlorides                   0.088685   1.000000             0.101392   
    free sulfur dioxide         0.299098   0.101392             1.000000   
    total sulfur dioxide        0.401439   0.198910             0.615501   
    density                     0.838966   0.257211             0.294210   
    pH                         -0.194133  -0.090439            -0.000618   
    sulphates                  -0.026664   0.016763             0.059217   
    alcohol                    -0.450631  -0.360189            -0.250104   
    quality                    -0.097577  -0.209934             0.008158   
    
                          total sulfur dioxide   density        pH  sulphates  \
    fixed acidity                     0.091070  0.265331 -0.425858  -0.017143   
    volatile acidity                  0.089261  0.027114 -0.031915  -0.035728   
    citric acid                       0.121131  0.149503 -0.163748   0.062331   
    residual sugar                    0.401439  0.838966 -0.194133  -0.026664   
    chlorides                         0.198910  0.257211 -0.090439   0.016763   
    free sulfur dioxide               0.615501  0.294210 -0.000618   0.059217   
    total sulfur dioxide              1.000000  0.529881  0.002321   0.134562   
    density                           0.529881  1.000000 -0.093591   0.074493   
    pH                                0.002321 -0.093591  1.000000   0.155951   
    sulphates                         0.134562  0.074493  0.155951   1.000000   
    alcohol                          -0.448892 -0.780138  0.121432  -0.017433   
    quality                          -0.174737 -0.307123  0.099427   0.053678   
    
                           alcohol   quality  
    fixed acidity        -0.120881 -0.113663  
    volatile acidity      0.067718 -0.194723  
    citric acid          -0.075729 -0.009209  
    residual sugar       -0.450631 -0.097577  
    chlorides            -0.360189 -0.209934  
    free sulfur dioxide  -0.250104  0.008158  
    total sulfur dioxide -0.448892 -0.174737  
    density              -0.780138 -0.307123  
    pH                    0.121432  0.099427  
    sulphates            -0.017433  0.053678  
    alcohol               1.000000  0.435575  
    quality               0.435575  1.000000  
    
    Red Wine Missing Values:
    


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[15], line 27
         25 # Display missing values and duplicate rows
         26 print("\nRed Wine Missing Values:")
    ---> 27 print(red_missing)
         29 print("\nWhite Wine Missing Values:")
         30 print(white_missing)
    

    NameError: name 'red_missing' is not defined



```python
# Visualization 1: Correlation Heatmap for Red Wine
plt.figure(figsize=(10, 8))
sns.heatmap(red_corr, annot=True, fmt=".2f", cmap="coolwarm", cbar=True)
plt.title("Red Wine Correlation Heatmap")
plt.show()

# Visualization 2: Correlation Heatmap for White Wine
plt.figure(figsize=(10, 8))
sns.heatmap(white_corr, annot=True, fmt=".2f", cmap="coolwarm", cbar=True)
plt.title("White Wine Correlation Heatmap")
plt.show()

# Visualization 3: Quality Distribution for Both Datasets
plt.figure(figsize=(10, 5))
sns.histplot(red_wine['quality'], kde=True, color='red', label='Red Wine Quality', bins=10)
sns.histplot(white_wine['quality'], kde=True, color='blue', label='White Wine Quality', bins=10)
plt.title("Wine Quality Distribution")
plt.xlabel("Quality")
plt.ylabel("Frequency")
plt.legend()
plt.show()

# Visualization 4: Alcohol vs Quality for Red Wine
plt.figure(figsize=(10, 5))
sns.boxplot(x='quality', y='alcohol', data=red_wine, palette="Reds", showfliers=False)
plt.title("Alcohol vs Quality - Red Wine")
plt.xlabel("Quality")
plt.ylabel("Alcohol Level")
plt.show()

# Visualization 5: Alcohol vs Quality for White Wine
plt.figure(figsize=(10, 5))
sns.boxplot(x='quality', y='alcohol', data=white_wine, palette="Blues", showfliers=False)
plt.title("Alcohol vs Quality - White Wine")
plt.xlabel("Quality")
plt.ylabel("Alcohol Level")
plt.show()
```


    
![png](output_3_0.png)
    



    
![png](output_3_1.png)
    


    C:\Users\elvir\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    C:\Users\elvir\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_3_3.png)
    



    
![png](output_3_4.png)
    



    
![png](output_3_5.png)
    



```python

```
